Please do not replace this .gz in git,

the best way would be to separate the structure from the data... (2 different sql files)

