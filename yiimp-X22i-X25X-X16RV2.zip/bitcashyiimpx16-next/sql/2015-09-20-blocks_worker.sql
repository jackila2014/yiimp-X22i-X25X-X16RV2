-- Recent additions to add after db init (.gz)

ALTER TABLE `blocks` ADD `workerid` INT(11) NULL AFTER `userid`;

